﻿Namespace Models
    Public Class Phone
        Property PhoneId() As Integer
        Property PhoneNumber() As String
        Property PersonId() As Integer
    End Class
End NameSpace