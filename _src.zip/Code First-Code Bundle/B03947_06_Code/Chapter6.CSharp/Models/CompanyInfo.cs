﻿namespace Chapter6.CSharp.Models
{
    public class CompanyInfo
    {
        public int CompanyId { get; set; }
        public string CompanyName { get; set; }
    }
}
