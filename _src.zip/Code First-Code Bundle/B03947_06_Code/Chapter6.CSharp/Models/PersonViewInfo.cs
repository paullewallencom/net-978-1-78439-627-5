﻿
namespace Chapter6.CSharp.Models
{
    public class PersonViewInfo
    {
        public int PersonId { get; set; }
        public string TypeName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }

}
