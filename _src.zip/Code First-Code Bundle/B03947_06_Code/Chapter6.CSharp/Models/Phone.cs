﻿namespace Chapter6.CSharp.Models
{
    public class Phone
    {
        public int PhoneId { get; set; }
        public string PhoneNumber { get; set; }
        public int PersonId { get; set; }
    }
}
