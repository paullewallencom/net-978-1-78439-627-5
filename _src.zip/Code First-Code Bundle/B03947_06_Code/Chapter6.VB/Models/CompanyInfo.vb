﻿Namespace Models
    Public Class CompanyInfo
        Property CompanyId() As Integer
        Property CompanyName() As String
    End Class
End Namespace