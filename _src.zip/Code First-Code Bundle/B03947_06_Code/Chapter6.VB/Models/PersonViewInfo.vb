﻿Namespace Models
Public Class PersonViewInfo
    Public Property PersonId() As Integer
    Public Property TypeName() As String
    Public Property FirstName() As String
    Public Property LastName() As String
End Class
End NameSpace