﻿namespace Chapter1.CSharp
{
    public class Person
    {
        public int Personid { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
    }
}
