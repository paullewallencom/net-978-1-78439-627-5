﻿

Public Class Person
    Property PersonId() As Integer
    Property LastName() As String
    Property FirstName() As String

End Class
