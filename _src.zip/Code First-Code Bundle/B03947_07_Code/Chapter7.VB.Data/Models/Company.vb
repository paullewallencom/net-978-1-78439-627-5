﻿Namespace Models
    Public Class Company
        Property CompanyId() As Integer
        Property Name() As String
    End Class
End NameSpace