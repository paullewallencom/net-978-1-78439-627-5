﻿Namespace Models
    Public Class Person
        Property PersonId() As Integer
        Property FirstName() As String
        Property LastName() As String
        Property NickName() As String
        Property Age() As Integer
        Property DateAdded() As DateTime
    End Class
End Namespace