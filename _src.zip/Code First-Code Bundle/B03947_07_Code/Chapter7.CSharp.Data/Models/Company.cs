﻿namespace Chapter7.CSharp.Data.Models
{
    public class Company
    {
        public int CompanyId { get; set; }
        public string Name { get; set; }
    }
}
