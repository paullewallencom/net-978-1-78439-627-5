﻿using System;

namespace Chapter7.CSharp.Data.Models
{
    public class Person
    {
        public int PersonId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string NickName { get; set; }
        public int Age { get; set; }
        public DateTime DateAdded { get; set; }
    }
}
