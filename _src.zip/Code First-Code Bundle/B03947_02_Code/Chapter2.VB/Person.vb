﻿Public Class Person
    Property PersonId() As Integer
    Property FirstName() As String
    Property LastName() As String

End Class
