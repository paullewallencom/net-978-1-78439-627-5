﻿namespace Chapter5.CSharp.Models
{
public enum PersonState
{
    Active,
    Inactive,
    Unknown
}
}
