﻿Namespace Models
Public Enum PersonState
    Active
    Inactive
    Unknown
End Enum
End NameSpace