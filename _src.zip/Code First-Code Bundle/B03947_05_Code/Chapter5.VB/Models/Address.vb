﻿Namespace Models
    Public Class Address
        Public Property Street() As String
        Public Property City() As String
        Public Property State() As String
        Public Property Zip() As String
    End Class
End NameSpace