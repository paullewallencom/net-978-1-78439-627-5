﻿Public Class Phone
    Property PhoneId() As Integer
    Property PhoneNumber() As String
End Class
