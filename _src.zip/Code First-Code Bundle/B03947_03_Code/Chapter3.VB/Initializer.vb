﻿Imports System.Data.Entity

Public Class Initializer
    Inherits DropCreateDatabaseIfModelChanges(Of Context)

End Class
